<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if user is logged in and is employer
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['user_type'] !== 'employer') {
    header("Location: ../login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];

// Fetch jobs posted by this employer
$stmt = $conn->prepare("SELECT id, title, location, salary, deadline FROM JOBS WHERE employer_id = ? ORDER BY deadline DESC");
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $jobs[] = $row;
    }
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <h1>Employer Dashboard</h1>
        <nav>
            <ul>
                <li><span>Welcome, Employer <?php echo htmlspecialchars($_SESSION['name']); ?>!</span></li>
                <li><a href="dashboard.php">My Jobs</a></li>
                <li><a href="add_job.php">Post New Job</a></li>
                <li><a href="upload_logo.php">Upload Logo</a></li>
                <li><a href="../profile.php">Profile</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main class="container">
        <h2>My Job Listings</h2>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success">
                <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error">
                <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (count($jobs) > 0): ?>
            <div class="job-list">
                <?php foreach ($jobs as $job): ?>
                    <div class="job-item">
                        <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                        <p><strong>Salary:</strong> $<?php echo htmlspecialchars(number_format($job['salary'], 2)); ?></p>
                        <p><strong>Deadline:</strong> <?php echo htmlspecialchars($job['deadline']); ?></p>
                        <a href="view_job.php?id=<?php echo $job['id']; ?>" class="button button-small">View Details</a>
                        <!-- Added link to view applicants -->
                        <a href="view_applicants.php?job_id=<?php echo $job['id']; ?>" class="button button-small">View Applicants</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>You haven't posted any jobs yet. <a href="add_job.php">Post your first job!</a></p>
        <?php endif; ?>

    </main>
    <footer>
        <p>&copy; 2023 Online Job Portal</p>
    </footer>
</body>
</html>