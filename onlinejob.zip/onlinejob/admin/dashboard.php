<?php
session_start();
// Check if user is logged in and is admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <nav>
            <ul>
                <li><span>Welcome, Admin <?php echo htmlspecialchars($_SESSION['name']); ?>!</span></li>
                <li><a href="../logout.php">Logout</a></li>
                <!-- Add a link to the profile page later -->
                <!-- <li><a href="../profile.php">Profile</a></li> -->
            </ul>
        </nav>
    </header>
    <main class="container">
        <h2>Welcome, Admin <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
        <p>This is the Admin Dashboard. More features coming soon.</p>
    </main>
    <footer>
        <p>&copy; 2023 Online Job Portal</p>
    </footer>
</body>
</html>