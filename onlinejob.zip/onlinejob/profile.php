<?php
session_start();
require_once 'db.php'; // Include the database connection file

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data from the database
$stmt = $conn->prepare("SELECT name, email, user_type FROM USERS WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();
    $name = $user['name'];
    $email = $user['email'];
    $user_type = $user['user_type'];
} else {
    // User not found, something is wrong with the session user_id
    // Redirect to logout or an error page
    header("Location: logout.php");
    exit();
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Online Job Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <h1>Online Job Portal</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
                    <li><span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</span></li>
                    <li><a href="profile.php">Profile</a></li> <!-- Link to this page -->
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php endif; ?>
                <li><a href="#">Browse Jobs</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <section class="form-section">
            <h2>Edit Profile</h2>
            <form action="update_profile.php" method="POST">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <!-- We won't allow changing user_type or password on this basic profile page -->
                <!-- Add password change functionality separately if needed -->

                <button type="submit" class="button">Update Profile</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Online Job Portal</p>
    </footer>
</body>
</html>